i z
i c
i k
i e
i j
i v
i m
i r
i x
i q
i f
i n
i t
i c
i p
i q
s
r
