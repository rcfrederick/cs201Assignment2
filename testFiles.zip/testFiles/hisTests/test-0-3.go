s
r
d e
d r
d o
d x
d g
d g
d u
d l
d w
d g
d l
d c
d r
d r
d e
d e
s
r
